# Android Shortcut Setup

App: HTTP Request Shortcuts (from Play Store)

1. Create New Shortcut
2. Method: POST
3. URL: https://<your-api-id>.execute-api.ap-south-1.amazonaws.com/start (or /stop)
4. Headers:
   - x-api-key: YOUR_API_KEY
5. Leave Body empty
6. Save and test

Repeat for /stop shortcut.